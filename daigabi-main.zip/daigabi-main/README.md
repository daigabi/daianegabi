### Bem vindos ao meu perfil💙

Meu nome é Daiane Gabriele

Estou estudando no [Alura](htts://www.aluracom.br )

Estou me desenvolvendo na líguagem JavaScript

utilizo esse espaço para minha organização e compartilhamentos dos meus projetos desenvolvidos

### Entre em contato comigo 📧

daianegabriele71@gmail.com

@daianegabriele

![](https://media1.tenor.com/m/_iheVyzHcTgAAAAC/bandeira-do-s%C3%A3o-paulo-s%C3%A3o-paulo-fc.gif)
